package com.example.my_menu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }//onCreate()

    //액티비티 타이틀바에 메뉴 호출 기능을 추가

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu,menu);
        /*메뉴바를 추가하기 위한 필수 구문*/
        return true;
    }

    //메뉴바에서 어떤 속성을 선택했는지 확인 메소드
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.adds:
                Toast.makeText(MainActivity.this,"add button click",Toast.LENGTH_SHORT).show();
                //makeText(Context(어떤 화면에서 보여줄것인가),title,호출시간)3개의 파라미터
                break;
            case R.id.edit:
                Toast.makeText(MainActivity.this,"edit button click",Toast.LENGTH_SHORT).show();
                break;
            case R.id.email:
                Toast.makeText(MainActivity.this,"email button click",Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
